package conn.bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class CategoryDAO {
	
	private Connection conn;
	private ResultSet rs;
	
	public CategoryDAO(){
		try{
			String dbURL="jdbc:mysql://localhost:3306/test";
			String dbID="root";
			String dbPassword="websys";
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
		}catch(Exception e){
			e.printStackTrace();
			
		}
	}
	
	public String getDate(){
		String SQL="select now()";
		try{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			if(rs.next()){
				return rs.getString(1);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return "";
		
	}
	
	public int getNext(){
		String SQL="select numnum from category order by numnum desc";
		try{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			if(rs.next()){
				return rs.getInt(1)+1;
			}
			return 1; //ù��° �Խù��� ���
		}catch(Exception e){
			e.printStackTrace();
		}
		return -1; //db����
		
	}
	
	public int write(String category, String value, int cnum, String turl1, String turl2, String imgurl, String vurl, String id){
		String SQL = "INSERT INTO category VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext());
			pstmt.setString(2, "exercise");
			pstmt.setString(3, value);
			pstmt.setInt(4, cnum);
			pstmt.setString(5, turl1);
			pstmt.setString(6, turl2);
			pstmt.setString(7, imgurl);
			pstmt.setString(8, vurl);
			pstmt.setString(9, id);
			pstmt.setInt(10, 1);
			return pstmt.executeUpdate();
	
		}catch(Exception e){
			
			e.printStackTrace();
			
		}
		return -1; // db����
		
		
	}
	
	
	 
	 public ArrayList<Category> getList(String value){
		String SQL = "select * from category where value = ? and available = 1";
		ArrayList<Category> list = new ArrayList<Category>();
		try{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
		//	pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);
			pstmt.setString(1, value);
			rs = pstmt.executeQuery();
			while(rs.next()){
				Category category = new Category();
				category.setNumnum(rs.getInt(1));
				category.setCategory(rs.getString(2));
				category.setValue(rs.getString(3));
				category.setCnum(rs.getInt(4));
				category.setTurl1(rs.getString(5));
				category.setTurl2(rs.getString(6));
				category.setImgurl(rs.getString(7));
				category.setVurl(rs.getString(8));
				category.setId(rs.getString(9));
				category.setAvailable(rs.getInt(10));
				list.add(category);
				
			}

		}catch(Exception e){
			
			e.printStackTrace();
			
		}
		return list; 
	}
	
	  
	
	
	public boolean nextPage(int pageNumber){
		String SQL = "select * from category where numnum < ? and available = 1";
		try{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);
			rs = pstmt.executeQuery();
			if(rs.next()){
				return true;
				
			}

		}catch(Exception e){
			
			e.printStackTrace();
			
		}
		return false; 
		
	}
	
	public Category getCategory(int numnum){
		String SQL = "select * from category where numnum = ?";
		try{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, numnum);
			rs=pstmt.executeQuery();
			if(rs.next()){
				Category category = new Category();
				category.setNumnum(rs.getInt(1));
				category.setCategory(rs.getString(2));
				category.setValue(rs.getString(3));
				category.setCnum(rs.getInt(4));
				category.setTurl1(rs.getString(5));
				category.setTurl2(rs.getString(6));
				category.setImgurl(rs.getString(7));
				category.setVurl(rs.getString(8));
				category.setId(rs.getString(9));
				category.setAvailable(rs.getInt(10));
				return category;
			}
		}catch (Exception e){
			e.printStackTrace();
		}
		return null;
		
	}
	
	public int update(int numnum, String turl1, String turl2, String imgurl, String vurl){
		String SQL = "update category set turl1 = ?, turl2 = ?, imgurl = ?, vurl = ? where numnum = ?";
		try{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, turl1);
			pstmt.setString(2, turl2);
			pstmt.setString(3, imgurl);
			pstmt.setString(4, vurl);
			pstmt.setInt(5, numnum);
		
			return pstmt.executeUpdate();
	
		}catch(Exception e){
			
			e.printStackTrace();
			
		}
		return -1; // db����
		
		
	}
	
	public int delete(int numnum){
		String SQL = "update category set available = 0 where numnum = ?";
		try{
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, numnum);
			return pstmt.executeUpdate();
	
		}catch(Exception e){
			
			e.printStackTrace();
			
		}
		return -1; // db����
		
		
	}
	
	
	
}
