package conn.bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MemberMgr {

	private DBConnectionMgr pool;

	public MemberMgr() {
		try {
			pool = DBConnectionMgr.getInstance();
		} catch (Exception e) {
			//e.printStackTrace();
			System.out.println("Error : 커넥션 연결 실패");
		}
	}

	// 회원가입
	public boolean insertMember(Member bean) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {

			con = pool.getConnection();
			sql = "insert Member(id,pw,name,email,sex,age,height,weight,bio,exercise)"
					+ "values(?,?,?,?,?,?,?,?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, bean.getId());
			pstmt.setString(2, bean.getPw());
			pstmt.setString(3, bean.getName());
			pstmt.setString(4, bean.getEmail());
			pstmt.setString(5, bean.getSex());
			pstmt.setString(6, bean.getAge());
			pstmt.setString(7, bean.getHeight());
			pstmt.setString(8, bean.getWeight());
			String bio[] = bean.getBio();
			char bi[] = { '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0' };
			String lists[] = { "일반/전신 및 기타", "귀", "근골격계", "내분비계/대사/영양", "눈", "비뇨기계", "소화기계", "신경계", "심혈관계", "정신/심리", "피부", "혈액/면역", "호흡기계", "성장" };
			for (int i = 0; i < bio.length; i++) {
				for (int j = 0; j < lists.length; j++) {
					if (bio[i].equals(lists[j]))
						bi[j] = '1';
				}
			}
			pstmt.setString(9, new String(bi));
			String exercise[] = bean.getExercise();
			char ex[] = { '0', '0', '0', '0', '0', '0', '0', '0', '0'};
			String listss[] = { "전신", "복부", "다리", "허리", "엉덩이", "등", "팔", "어깨", "가슴" };
			for (int i = 0; i < exercise.length; i++) {
				for (int j = 0; j < listss.length; j++) {
					if (exercise[i].equals(listss[j]))
						ex[j] = '1';
				}
			}
			pstmt.setString(10, new String(ex));
			if (pstmt.executeUpdate() > 0)
				flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return flag;
	}

	// /로그인
	public boolean loginMember(String id, String pw) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "select id from Member where id=? and pw=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			rs = pstmt.executeQuery();
			flag = rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return flag;
	}

	// 회원정보가져오기
	public Member getMember(String id) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Member bean = null;
		try {
			con = pool.getConnection();
			String sql = "select * from Member where id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				bean = new Member();
				bean.setId(rs.getString("id"));
				bean.setPw(rs.getString("pw"));
				bean.setName(rs.getString("name"));
				bean.setEmail(rs.getString("email"));
				bean.setSex(rs.getString("sex"));
				bean.setAge(rs.getString("age"));
				bean.setHeight(rs.getString("height"));
				bean.setWeight(rs.getString("weight"));
				String bios[] = new String[14];
				String bio = rs.getString("bio");
				for (int i = 0; i < bios.length; i++) {
					bios[i] = bio.substring(i, i + 1);
				}
				bean.setBio(bios);
				String exercises[] = new String[9];
				String exercise = rs.getString("exercise");
				for (int i = 0; i < exercises.length; i++) {
					exercises[i] = exercise.substring(i, i + 1);
				}
				bean.setExercise(exercises);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con);
		}
		return bean;
	}

	// 마이페이지 정보수정
	public boolean updateMember(Member bean) {
		Connection con = null;
		PreparedStatement pstmt = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			String sql = "update Member set pw=?,name=?,email=?,sex=?,"
					+ "age=?,height=?,weight=? where id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, bean.getPw());
			pstmt.setString(2, bean.getName());
			pstmt.setString(3, bean.getEmail());
			pstmt.setString(4, bean.getSex());
			pstmt.setString(5, bean.getAge());
			pstmt.setString(6, bean.getHeight());
			pstmt.setString(7, bean.getWeight());
			pstmt.setString(8, bean.getId());
			int count = pstmt.executeUpdate();
			if (count > 0)
				flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return flag;
	}
	
	
	// 관심 건강정보수정
		public boolean updateBioMember(Member bean) {
			Connection con = null;
			PreparedStatement pstmt = null;
			boolean flag = false;
			try {
				con = pool.getConnection();
				String sql = "update Member set bio=?,exercise=? where id=?";
				pstmt = con.prepareStatement(sql);
				char bio[] = { '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0' };
				if (bean.getBio() != null) {
					String bios[] = bean.getBio();
					String list[] = { "일반/전신 및 기타", "귀", "근골격계", "내분비계/대사/영양", "눈", "비뇨기계", "소화기계", "신경계", "심혈관계", "정신/심리", "피부", "혈액/면역", "호흡기계", "성장" };
					for (int i = 0; i < bios.length; i++) {
						for (int j = 0; j < list.length; j++)
							if (bios[i].equals(list[j]))
								bio[j] = '1';
					}
				}
				pstmt.setString(1, new String(bio));
				char exercise[] = { '0', '0', '0', '0', '0', '0', '0', '0', '0' };
				if (bean.getExercise() != null) {
					String exercises[] = bean.getExercise();
					String lists[] = { "전신", "복부", "다리", "허리", "엉덩이", "등", "팔", "어깨", "가슴" };
					for (int i = 0; i < exercises.length; i++) {
						for (int j = 0; j < lists.length; j++)
							if (exercises[i].equals(lists[j]))
								exercise[j] = '1';
					}
				}
				pstmt.setString(2, new String(exercise));
				pstmt.setString(3, bean.getId());
				int count = pstmt.executeUpdate();
				if (count > 0)
					flag = true;
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pool.freeConnection(con, pstmt);
			}
			return flag;
		}
	
	
}
