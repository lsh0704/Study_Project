package conn.bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;

public class memberDAO {
	
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public memberDAO(){
		try{
			String dbURL="jdbc:mysql://localhost:3306/test";
			String dbID="root";
			String dbPassword="websys";
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
		}catch(Exception e){
			e.printStackTrace();
			
		}
	}
	
	public int login(String id, String pw){
		String SQL="SELECT pw FROM member WHERE id = ?";
		try{
			pstmt=conn.prepareStatement(SQL);
			pstmt.setString(1, id);
			rs=pstmt.executeQuery();
			if(rs.next()){
				if(rs.getString(1).equals(pw))
					return 1; // �α��� ����
				
				else
					return 0; // ��й�ȣ ����ġ
				
			}
			return -1; // ���̵� ����
		}catch(Exception e){
			e.printStackTrace();
		}
		return -2; // �����ͺ��̽� ����

	}
}
