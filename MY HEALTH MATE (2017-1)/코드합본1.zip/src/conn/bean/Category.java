package conn.bean;
import java.util.*;

public class Category {
		private int numnum;
		private String category;
	    private String value;
	    private int cnum;
	    private String turl1;
	    private String turl2;
	    private String imgurl;
	    private String vurl;
	    private String id; // �������̵�
	    private int available;
	    
	    
	    //getter methods
	   
	    public int getNumnum() {
	        return numnum;
	    }
	    public String getCategory() {
	        return category;
	    }
	    public String getValue() {
	        return value;
	    }
	    public int getCnum() {
	        return cnum;
	    }
	    public String getTurl1() {
	        return turl1;
	    }
	    public String getTurl2() {
	        return turl2;
	    }
	    public String getImgurl() {
	        return imgurl;
	    }
	    public String getVurl() {
	        return vurl;
	    }
	    public String getId() {
	        return id;
	    }
	    public int getAvailable() {
	        return available;
	    }
	    
	    //setter methods
	    public void setNumnum(int numnum) {
	        this.numnum =  numnum;
	    }
	    public void setCategory(String category) {
	        this.category = category;
	    }
	    public void setValue(String value) {
	        this.value = value;
	    }
	    public void setCnum(int cnum) {
	        this.cnum = cnum;
	    }
	    public void setTurl1(String turl1) {
	        this.turl1 = turl1;
	    }
	    public void setTurl2(String turl2) {
	        this.turl2 = turl2;
	    }
	    public void setImgurl(String imgurl) {
	        this.imgurl = imgurl;
	    }
	    public void setVurl(String vurl) {
	        this.vurl = vurl;
	    }
	    public void setId(String id) {
	        this.id = id;
	    }
	    public void setAvailable(int available) {
	        this.available = available;
	    }
	

}
